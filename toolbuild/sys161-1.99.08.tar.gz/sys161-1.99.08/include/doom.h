/*
 * Doom counter interface.
 */

void doom_establish(unsigned count);
